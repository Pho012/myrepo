// Nova Island — reference implementation.
// Target: iOS 16.0+, rootless, iphoneos-arm64.
// This file is intentionally kept as source because this environment does not
// contain Apple's iPhoneOS SDK / ld64 toolchain needed to produce a verified
// injectable SpringBoard dylib.
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

static BOOL NIEnabled(void) {
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"Enabled"];
}

// The production implementation should attach to SpringBoard and create a
// top-center rounded black UIView, then expand/update it for system events.
// Preferences are stored under com.mecitsendi.novaisland.
%ctor {
    if (!NIEnabled()) return;
    // Hook/injection implementation belongs here.
}
