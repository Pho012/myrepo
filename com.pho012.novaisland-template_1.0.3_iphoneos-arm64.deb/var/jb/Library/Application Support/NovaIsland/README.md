# Nova Island
Rootless `iphoneos-arm64` package skeleton for iOS 16.x.

Important: this archive is **not a verified working tweak binary**. The build environment used here has no Apple iPhoneOS SDK/ld64 toolchain, so I did not fabricate a dylib and label it as working.

The included source is designed around a SpringBoard injection + PreferenceLoader switch. A production build should be compiled with Theos using `THEOS_PACKAGE_SCHEME=rootless`, which makes the package architecture `iphoneos-arm64` and installs under `/var/jb`.

Your requested target is iPhone 8 / iOS 16.7.16. Existing Dynamic Island tweaks documented online generally target notched devices and/or older iOS 16 builds, so their binaries should not be assumed compatible with this exact setup.
